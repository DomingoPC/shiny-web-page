server <- function(input, output, session) {
}

shinyApp(NULL, server)
