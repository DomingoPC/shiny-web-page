function(input, output) {
  
}
