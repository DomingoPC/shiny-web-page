#!/bin/sh

wget http://notebook.gaslampmedia.com/wp-content/uploads/2013/08/zip_codes_states.csv
wget http://www.aei.org/files/2012/02/16/-revisedmurrayfile_111952895138.xls
