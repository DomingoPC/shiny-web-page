We have three tables in this example:

- For the `diamonds` data, we can select variables to show in the table.

- For the `mtcars` example, we use `orderClasses = TRUE` so that sorted
  columns are colored since they have special CSS classes attached.

- For the `iris` data, we customize the length menu so we can display 5 rows
  per page.
