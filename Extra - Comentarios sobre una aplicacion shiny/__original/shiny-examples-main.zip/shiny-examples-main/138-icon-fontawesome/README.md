This app demonstrates using `icon` to create [FontAwesome](https://fontawesome.com/) icons.
